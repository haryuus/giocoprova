---
title: "mg_mgr_free()"
decl_name: "mg_mgr_free"
symbol_kind: "func"
signature: |
  void mg_mgr_free(struct mg_mgr *mgr);
---

De-initialises Mongoose manager.

Closes and deallocates all active connections. 

