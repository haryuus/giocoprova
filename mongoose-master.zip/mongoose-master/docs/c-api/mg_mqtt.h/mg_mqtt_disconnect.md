---
title: "mg_mqtt_disconnect()"
decl_name: "mg_mqtt_disconnect"
symbol_kind: "func"
signature: |
  void mg_mqtt_disconnect(struct mg_connection *nc);
---

Sends a DISCONNECT command. 

