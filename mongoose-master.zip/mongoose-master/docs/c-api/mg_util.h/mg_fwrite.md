---
title: "mg_fwrite()"
decl_name: "mg_fwrite"
symbol_kind: "func"
signature: |
  size_t mg_fwrite(const void *ptr, size_t size, size_t count, FILE *f);
---

Writes data to the given file stream.

Return value is a number of bytes wtitten. 

